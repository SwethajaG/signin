import { NumberDirective } from './number.directive';

describe('NumberDirective', () => {
  it('should create an instance', () => {
    const directive = new NumberDirective();
    expect(directive).toBeTruthy();
  });
});
