import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../../services/student.service';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent implements OnInit {

  submitted = false;
  id = 0;
  x: any;
  update = false;
  profileForm = this.fb.group({
    name: ['', Validators.required],
    rollno: ['', Validators.required],
    fathername: ['', Validators.required],
    class: ['', Validators.required],
    mailid: ['', [Validators.required, Validators.email]],
    mobileno: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
    address: [''],
    id: [0]
  });

  errorMessage = '';


  constructor(private studentService: StudentService, private router: Router, private fb: FormBuilder, private route: ActivatedRoute) {
    this.id = this.route.snapshot.params.id;
    if (this.id > 0) {
      this.update = true;
      this.getStudentById(this.id);
    }
  }

  ngOnInit(): void {

  }

  save() {
    if (this.id === 0 || this.id === null || this.id === undefined) {
      this.saveStudent();
    } else if (this.id > 0) {
      this.updateStudent();
    } else {
      this.clearAll();
    }
  }

  saveStudent() {
    this.submitted = true;
    if (this.profileForm.valid) {
      this.studentService.createStudent(this.profileForm.value).subscribe((data: any) => {
        this.message();
      });
    }
  }

  getStudentById(id: any) {
    this.studentService.getStudentById(id).subscribe((data: any) => {
      this.profileForm.setValue({
        name: data.name,
        rollno: data.rollno,
        fathername: data.fathername,
        class: data.class,
        mailid: data.mailid,
        mobileno: data.mobileno,
        address: data.address,
        id: this.id
      });

    });
  }

  updateStudent() {
    if (this.profileForm.valid) {
      this.studentService.updateStudent(this.profileForm.value).subscribe((data: any) => {
        this.router.navigate(['/viewstudent']);
      });
    }
  }

  clearAll() {
    this.profileForm.patchValue({
      name: '',
      rollno: '',
      fathername: '',
      class: '',
      mailid: '',
      mobileno: '',
      address: '',
      id: 0
    });
    this.errorMessage = '';
    this.submitted = false;
  }

  get controls() {
    return this.profileForm.controls;
  }

  cancel() {
    this.router.navigate(['/viewstudent']);
  }
  message() {
    this.x  = document.getElementById('snackbar');
    this.x.className = 'show';
    setTimeout( () => { this.x.className = this.x.className.replace('show', ''); this.clearAll(); }, 1000);
  }

}
