import { Component, OnInit } from '@angular/core';
import { StudentService } from '../../services/student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewstudent',
  templateUrl: './viewstudent.component.html',
  styleUrls: ['./viewstudent.component.css']
})
export class ViewstudentComponent implements OnInit {

  students: any;
  searchTerm = '';
  x: any;
  deleteStudentId =  0;

  constructor(private studentService: StudentService, private router: Router) {
    this.getAllStudents();
  }

  ngOnInit(): void {
  }

  getAllStudents() {
    this.studentService.getAllStudents().subscribe((data: any) => {
      this.students = data;
    });
  }

  editStudent(student: any) {
    this.router.navigate(['/addstudent/' + student.id]);
  }

  deleteStudent(student: any) {
    this.studentService.deleteStudent(student.id).subscribe((data: any) => {
      this.getAllStudents();
    });
  }
  deletemessage(student: any) {
    this.deleteStudentId = student.id;
    this.x  = document.getElementById('snackbar');
    this.x.className = 'show';
    //setTimeout( () => { this.x.className = this.x.className.replace('show', '');  }, 1000);
  }
  closeToast(){
    this.x.className = '';
  }


}

