import { Component, DoCheck } from '@angular/core';
import { UserService } from './services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck{
  title = 'signin';
  isLogined = this.userService.userName === '' ? false : true;
  constructor(private userService: UserService, private router: Router){
    this.router.navigate(['/signin']);
  }
  ngDoCheck(): void {
    this.isLogined = this.userService.userName === '' ? false : true;
  }
}
